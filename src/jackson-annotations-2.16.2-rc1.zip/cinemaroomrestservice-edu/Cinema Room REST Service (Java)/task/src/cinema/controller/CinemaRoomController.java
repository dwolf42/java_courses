package cinema.controller;

import cinema.model.Room;
import cinema.model.Seats;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CinemaRoomController {

    @GetMapping("/seats")
    public Room getRoom() {
        List<Seats> seats = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= 9; j++) {
                seats.add(new Seats(i, j));
            }
        }

        Room room = new Room(9, 9, seats);
        return room;
    }

}
