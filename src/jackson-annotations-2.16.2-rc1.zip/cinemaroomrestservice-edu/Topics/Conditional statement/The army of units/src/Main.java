import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            int army = scanner.nextInt();
            if (army < 1) {
                System.out.println("no army");
            }
            if (army >= 1 && army <= 19) {
                System.out.println("pack");
            }
            if (army >= 20 && army <= 249) {
                System.out.println("throng");
            }
            if (army >= 250 && army <= 999) {
                System.out.println("zounds");
            }
            if (army >= 1000) {
                System.out.println("legion");
            }
        }
    }
}