import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

		int n = scanner.nextInt(); // 2002

		String str1 = Integer.toString(n); // transform int to String

		if (str1.charAt(0) == str1.charAt(str1.length() - 1) && str1.charAt(1) == str1.charAt(2)) {

	  
	  System.out.println(1);
	  } else {
			System.out.println(837);
	  }
	}
}
