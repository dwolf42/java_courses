package my_calc_oop;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class CalculatorEngineOOPTest {
    @Test
    void testEngineCalculator() {
        CalculatorGuiOOP gui = new CalculatorGuiOOP();
        CalculatorEngineOOP calcEngineOOP = new CalculatorEngineOOP(gui);

        String result1 = calcEngineOOP.calculate("5*7+3/2+0.05*0.005");
        String result2 = calcEngineOOP.calculate("832+6596/87+36-87.25");
        String result3 = calcEngineOOP.calculate("8*3-2.587410+5.369*1205/0.000001*6");
        String result4 = calcEngineOOP.calculate("53966*53348/41548+17562-6382+(17123.30713-79545)");
        String result5 = calcEngineOOP.calculate("3.14*10");

        Assertions.assertEquals("36.50025", result1);
        Assertions.assertEquals("856.56609", result2);
        Assertions.assertEquals("38817870021.41259", result3);
        Assertions.assertEquals("18051.12912", result4);
        Assertions.assertEquals("31.4", result5);
    }


}
