package my_calc_oop;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorGuiOOPTest {

    private CalculatorGuiOOP gui;

    @BeforeEach
    public void setUp() {
        gui = new CalculatorGuiOOP();
        gui.userInput = "";
    }

    // Display tests
    @Test
    void testUpdateDisplayWithEmptyValue() {
        gui.userInput = "5";
        gui.updateDisplay("");
        assertEquals("", gui.display.getText());
    }

    @Test
    void testUpdateDisplayWithNonEmptyValue() {
        gui.userInput = "";
        gui.updateDisplay("5+2");
        assertEquals("5+2", gui.display.getText());
    }

    // userInput tests
    @Test
    void testClearUserInput() {
        gui.userInput = "8920";
        gui.clearUserInput();
        assertEquals("", gui.userInput);
    }

    @Test
    void testGetUserInputNoWhitespace() {
        gui.userInput = "7 + 29 + 9";
        assertEquals("7+29+9", gui.getUserInputNoWhitespace());
    }


    // Input from clicked buttons tests
    @Test
    void testButtonClickedOperators() {
        gui.buttonClicked("+");
        assertEquals(" + ", gui.display.getText());
    }

    @Test
    void testButtonClickedNumbers() {
        gui.buttonClicked("1");
        assertEquals("1", gui.display.getText());
    }

    @Test
    void testButtonClickedCE() {
        gui.userInput = "2214 + 412";
        gui.buttonClicked("CE");
        assertEquals("", gui.display.getText());

    }

    @Test
    void testButtonClickedEquals() {
        gui.userInput = "22 + 5";
        gui.buttonClicked("=");
        assertEquals("27", gui.display.getText());
    }



}