package jetbrains_tutorial_calc;

import jetbrains_tutorial_calc.CalculatorJetBrains;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

class CalculatorJetBrainsTests {

    @Test
//    @DisplayName("Add 1 and 2, result should be 3")
    void testAddition() {
        CalculatorJetBrains calculator = new CalculatorJetBrains();
        int result = calculator.add(1, 2);

        Assertions.assertEquals(3, result);
    }

    @Test
    void testMultiplication() {
        CalculatorJetBrains calculator = new CalculatorJetBrains();
        int result = calculator.multiply(2, 3);

        Assertions.assertEquals(6, result);
    }
}