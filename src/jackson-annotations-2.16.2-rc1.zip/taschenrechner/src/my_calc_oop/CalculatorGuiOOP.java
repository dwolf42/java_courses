package my_calc_oop;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * # Advanced calculator with GUI
 * ## ~Class description~
 * Handles calculator's frontend.
 * Pressed buttons will be stored by their character representation as a string.
 * This string is then used to display input, and handed to the engine for calculations.
 * */

public class CalculatorGuiOOP extends JFrame implements ActionListener {
    public final JTextField display;
    private final CalculatorEngineOOP engine;

    public String userInput = "";

    public CalculatorGuiOOP() {

        // Main panel layout (Background)
        setTitle("Calculator");
        setSize(322, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBackground(new Color(232, 232, 232));
        setLayout(null);
        setFont(new Font(Font.DIALOG_INPUT, Font.PLAIN, 30));

        // Component instantiation
        display = new JTextField(16); // Display must be set here for updateDisplay to work
        engine = new CalculatorEngineOOP(this);

        // TextField layout
        display.setFont(new Font(Font.DIALOG_INPUT, Font.PLAIN, 20));
        display.setMaximumSize(new Dimension(200, 64));
        display.setDisabledTextColor(new Color(0, 0, 0));
        // margin space between the text field's border and its text
        display.setMargin(new Insets(2, 10, 2, 10));
        display.setText(userInput);
        display.setBounds(20, 25, 208, 64);
        display.setEditable(false);
        display.setBackground(new Color(255, 255, 255));

        // Add components to panel
        add(display);
        add(createButtonsPanel());
    }

    public void actionPerformed(ActionEvent ae) {
        buttonClicked(
                ((JButton) ae.getSource()).getText()
        );
    }

    // Separate from constructor, since the engine will have to access it
    public void updateDisplay(String value) {
        if (value.isEmpty()) {
            clearUserInput();
            display.setText(userInput);
        } else {
            userInput = userInput.concat(value);
            display.setText(userInput);
        }
    }

    public String getUserInputNoWhitespace() {
        return userInput.replaceAll(" ", "");
    }

    public void clearUserInput() {
        userInput = "";
    }

    public JPanel createButtonsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(0, 0, 316, 450);

        panel.setPreferredSize(new Dimension(300, 200));

        /* ~ Button Row 1 ~ */
        // Button CE
        JButton buttonCE = new JButton("CE");
        // Beginn(x), Previous object size(x1), buffer(x2)
        buttonCE.setBounds(20 + 208 + 8, 25, 64, 64);
        buttonCE.setBackground(new Color(252, 74, 3));
        buttonCE.setBorderPainted(true);
        buttonCE.addActionListener(this);
        panel.add(buttonCE);


        /* ~ Button Row 2 ~ */
        // Button 7
        JButton button7 = new JButton("7");
        button7.setBounds(20, 25 + 64 + 8, 64, 64);
        button7.setBackground(new Color(250, 238, 230));
        button7.setBorderPainted(true);
        button7.addActionListener(this);
        panel.add(button7);

        // Button 8
        JButton button8 = new JButton("8");
        button8.setBounds(20 + 64 + 8, 25 + 64 + 8, 64, 64);
        button8.setBackground(new Color(250, 238, 230));
        button8.setBorderPainted(true);
        button8.addActionListener(this);
        panel.add(button8);

        // Button 9
        JButton button9 = new JButton("9");
        button9.setBounds(20 + 136 + 8, 25 + 64 + 8, 64, 64);
        button9.setBackground(new Color(250, 238, 230));
        button9.setBorderPainted(true);
        button9.addActionListener(this);
        panel.add(button9);

        // Button '/'
        JButton buttonDivide = new JButton("/");
        buttonDivide.setBounds(20 + 208 + 8, 25 + 64 + 8, 64, 64);
        buttonDivide.setBackground(new Color(158, 233, 247));
        buttonDivide.setBorderPainted(true);
        buttonDivide.addActionListener(this);
        panel.add(buttonDivide);


        /* ~ Button Row 3 ~ */
        // Button 4
        JButton button4 = new JButton("4");
        button4.setBounds(20, 25 + 136 + 8, 64, 64);
        button4.setBackground(new Color(250, 238, 230));
        button4.setBorderPainted(true);
        button4.addActionListener(this);
        panel.add(button4);

        // Button 5
        JButton button5 = new JButton("5");
        button5.setBounds(20 + 64 + 8, 25 + 136 + 8, 64, 64);
        button5.setBackground(new Color(250, 238, 230));
        button5.setBorderPainted(true);
        button5.addActionListener(this);
        panel.add(button5);

        // Button 6
        JButton button6 = new JButton("6");
        button6.setBounds(20 + 136 + 8, 25 + 136 + 8, 64, 64);
        button6.setBackground(new Color(250, 238, 230));
        button6.setBorderPainted(true);
        button6.addActionListener(this);
        panel.add(button6);

        // Multiply '*'
        JButton buttonMultiply = new JButton("*");
        buttonMultiply.setBounds(20 + 208 + 8, 25 + 136 + 8, 64, 64);
        buttonMultiply.setBackground(new Color(158, 233, 247));
        buttonMultiply.setBorderPainted(true);
        buttonMultiply.addActionListener(this);
        panel.add(buttonMultiply);


        /* ~ Row 4 ~ */
        // Button 1
        JButton button1 = new JButton("1");
        button1.setBounds(20, 25 + 208 + 8, 64, 64);
        button1.setBackground(new Color(250, 238, 230));
        button1.setBorderPainted(true);
        button1.addActionListener(this);
        panel.add(button1);

        // Button 2
        JButton button2 = new JButton("2");
        button2.setBounds(20 + 64 + 8, 25 + 208 + 8, 64, 64);
        button2.setBackground(new Color(250, 238, 230));
        button2.setBorderPainted(true);
        button2.addActionListener(this);
        panel.add(button2);

        // Button 3
        JButton button3 = new JButton("3");
        button3.setBounds(20 + 136 + 8, 25 + 208 + 8, 64, 64);
        button3.setBackground(new Color(250, 238, 230));
        button3.setBorderPainted(true);
        button3.addActionListener(this);
        panel.add(button3);

        // Subtraction '-'
        JButton buttonSubtract = new JButton("-");
        buttonSubtract.setBounds(20 + 208 + 8, 25 + 208 + 8, 64, 64);
        buttonSubtract.setBackground(new Color(158, 233, 247));
        buttonSubtract.setBorderPainted(true);
        buttonSubtract.addActionListener(this);
        panel.add(buttonSubtract);


        /* ~ Row 5 ~ */
        // Button 0
        JButton button0 = new JButton("0");
        button0.setBounds(20, 25 + 280 + 8, 64, 64);
        button0.setBackground(new Color(250, 238, 230));
        button0.setBorderPainted(true);
        button0.addActionListener(this);
        panel.add(button0);

        // Decimal '.'
        JButton buttonDecimal = new JButton(".");
        buttonDecimal.setBounds(20 + 64 + 8, 25 + 280 + 8, 64, 64);
        buttonDecimal.setBackground(new Color(158, 233, 247));
        buttonDecimal.setBorderPainted(true);
        buttonDecimal.addActionListener(this);
        panel.add(buttonDecimal);

        // Equal '='
        JButton buttonEqual = new JButton("=");
        buttonEqual.setBounds(20 + 136 + 8, 25 + 280 + 8, 64, 64);
        buttonEqual.setBackground(new Color(128, 242, 124));
        buttonEqual.setBorderPainted(true);
        buttonEqual.addActionListener(this);
        panel.add(buttonEqual);

        // Addition '+'
        JButton buttonAddition = new JButton("+");
        buttonAddition.setBounds(20 + 208 + 8, 25 + 280 + 8, 64, 64);
        buttonAddition.setBackground(new Color(158, 233, 247));
        buttonAddition.setBorderPainted(true);
        buttonAddition.addActionListener(this);
        panel.add(buttonAddition);

        return panel;
    }

    public void buttonClicked(String buttonText) {
        switch (buttonText) {
            case "+":
            case "-":
            case "*":
            case "/":
                updateDisplay(" " + buttonText + " ");
                break;
            case "=":
                String result = engine.calculate(getUserInputNoWhitespace());
                clearUserInput();
                updateDisplay(result);
                break;
            case "CE":
                updateDisplay("");
                break;
            default:
                updateDisplay(buttonText);
                break;
        }
    }

}
