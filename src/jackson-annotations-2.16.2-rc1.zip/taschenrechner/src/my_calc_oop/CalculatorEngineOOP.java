package my_calc_oop;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import java.util.Locale;

/*
 * # Advanced calculator with GUI
 * ## ~Class description~
 * Handles calculator's backend.
 * Evaluates the string cleansed of whitespace which was formed from buttons pressed.
 * Result is returned to the GUI.
 * */

public class CalculatorEngineOOP {
    private final CalculatorGuiOOP gui;

    public CalculatorEngineOOP(CalculatorGuiOOP gui) {
        this.gui = gui;
    }

    public String calculate(String input) {
        Expression expression = new ExpressionBuilder(input).build();
        // Evaluation is required, to avoid NumberFormatException from of missing "e" notation
        double evaluated = expression.evaluate();

        double whole = Math.floor(evaluated);
        double fraction = evaluated - whole;

        if (fraction == 0) {
            int toInt = (int) evaluated;
            return String.valueOf(toInt);
        } else {
            // Add or remove '#' after the '.' to adjust decimal places
            return new DecimalFormat("#.#####",
                    new DecimalFormatSymbols(Locale.ENGLISH)).format(evaluated);
        }
    }



}