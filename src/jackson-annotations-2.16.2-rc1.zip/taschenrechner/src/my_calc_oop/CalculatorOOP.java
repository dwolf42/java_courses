package my_calc_oop;

/*
 * # Advanced calculator with GUI
 * ## ~Class description~
 * Creates a GUI and sets it visible
 * */

// basic calculator finished 25.07.23 4:58 pm
// improved algorithm 26.07.23 10:27 am
// operator precedence 28.07.23 1:07 pm
// reusing result 28.07.23 1:45 pm
// GUI and calculator functions reworked 01.08. 1:53 pm
// GUI look and feel 01.08. 4:40 pm
// calculation improvements, fix decimal issues

public class CalculatorOOP {
    public static void main(String[] args) {
        CalculatorGuiOOP gui = new CalculatorGuiOOP();
        gui.setVisible(true);
    }
}
