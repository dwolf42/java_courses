package approaches_gui_calc;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class HandleInputTest {

    static String hasSpace = "5 * 7 + 3 / 2 + 0.05 * 0.005";
    public static void main(String[] args) {

//        String remSpace = operation.toString().replaceAll("", " ");

        remSpace();
        evaluate();
        printIt();
        resetHasSpace();
        printIt();


        // As soon as the = get smashed, I call removeSpaces and push it to the display, as well als setting
        // output to ""
    }

    private static void remSpace() {
        hasSpace = hasSpace.replaceAll(" ", "");
    }

    private static void evaluate() {
        Expression expression = new ExpressionBuilder(hasSpace).build();
        hasSpace = String.valueOf(expression.evaluate());
    }

    private static void printIt() {
        System.out.println("result: " + hasSpace);
    }

    private static void resetHasSpace() {
        hasSpace = "";
    }
}
