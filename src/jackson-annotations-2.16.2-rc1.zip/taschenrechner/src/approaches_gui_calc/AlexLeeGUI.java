package approaches_gui_calc;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;

public class AlexLeeGUI implements ActionListener {
    JLabel label;
    JFrame frame;
    JButton button;
    JPanel panel;
    int count = 0;

    public AlexLeeGUI() {
        frame = new JFrame();

        button = new JButton("Click me");
        // implements "ActionListener"
        button.addActionListener(this);

        label = new JLabel("Number of clicks: ");

        panel = new JPanel();
        // top = height, left = width l->r, bottom = also height, right = also width l->r,
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
        // rows and columns
        panel.setLayout(new GridLayout());
        panel.add(button);
        panel.add(label);

        frame.add(panel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("calculator_template");
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new AlexLeeGUI();

    }

    public void actionPerformed(ActionEvent e) {
        count++;
        label.setText("Number of clicks: " + count);
    }
}
