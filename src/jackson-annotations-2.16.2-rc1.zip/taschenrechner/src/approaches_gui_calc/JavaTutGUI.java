package approaches_gui_calc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JavaTutGUI {
    private JFrame frame;
    private JPanel panel;
    private JButton addButton;
    private JButton subtractButton;
    private JTextField input1;
    private JTextField input2;
    private JLabel resultLabel;

    // Constructor initializes the GUI components
    public JavaTutGUI() {
        frame = new JFrame("calculator_template");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel(new GridLayout(5, 4));

//        input1 = new JTextField();
//        input2 = new JTextField();

        addButton = createButton("+");
        subtractButton = createButton("-");

        resultLabel = new JLabel("Result: ");

        panel.add(new JLabel("Input 1:"));
        panel.add(input1);
        panel.add(new JLabel("Input 2:"));
        panel.add(input2);
        panel.add(addButton);
        panel.add(resultLabel);

        frame.add(panel);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.addActionListener(new CalculatorListener());
        return button;
    }

    // Method to display the GUI
    public void display() {
        frame.setVisible(true);
    }

    private class CalculatorListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            double num1 = Double.parseDouble(input1.getText());
            double num2 = Double.parseDouble(input2.getText());
            double result;

            if (e.getSource() == addButton) {
                result = num1 + num2;
                resultLabel.setText("Result: " + result);
            } else if (e.getSource() == subtractButton) {
                result = num1 - num2;
                resultLabel.setText("Result: " + result);
            }
        }

    }

    public static void main(String[] args) {
        JavaTutGUI calculator = new JavaTutGUI();
        calculator.display();
//        JFrame frame = new JFrame("Calculator");
////        frame.setSize(450, 400);
//        JPanel panel = new JPanel();
//
//        JButton button_7 = new JButton("7");
//        panel.add(button_7); // creates button
//        frame.add(panel); // adds button to frame
//
//        JButton button_8 = new JButton("8");
//        panel.add(button_8); // creates button
//        frame.add(panel); // adds button to frame
//
//        JButton button_9 = new JButton("9");
//        panel.add(button_9); // creates button
//        frame.add(panel); // adds button to frame
//
//        frame.pack(); // window size fits content
//
//        frame.setVisible(true);

    }


}
