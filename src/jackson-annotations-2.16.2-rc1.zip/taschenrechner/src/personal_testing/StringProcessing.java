package personal_testing;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.regex.Pattern;

public class StringProcessing {
   private static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
    public static void main(String[] args) {

     LinkedList<String> testOutput = new LinkedList<>();
     testOutput.add("q");
     testOutput.add("x");

//        System.out.println(testOutput.toString().replaceAll("\\[", "").replaceAll("\\]", ""));

        System.out.println(testOutput);

        StringBuilder builder = new StringBuilder();
        builder.append("a");
        builder.append(" ");
        builder.append("a");
        builder.append(" ");
        builder.append("a");
        String cleanedString = builder.toString().replaceAll(" ", "");
        builder.setLength(0);
        builder.append(cleanedString);

        double toReplace = 2.5;
        builder.replace(builder.length() - 1, builder.length(), Double.toString(toReplace));
        System.out.println(builder);
        System.out.println(builder.length());

        String operation1 = "5*7+3/2+0.05*0.005"; // 36.50025
        String operation2 = "(2-3)*10-7/2"; // 36.50025
        Expression expression = new ExpressionBuilder(operation1).build();
        double result = expression.evaluate();
        System.out.println("result: " + result);
    }

    public static String biggerDecimal(String num) {
        String amount = null;
        amount = new BigDecimal(num).toString();
        return amount;
    }

    public static String subString(String str) {
        String subStr = str.substring(str.indexOf("+") + 1);
      return subStr;
    }
    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        return pattern.matcher(strNum).matches();
    }
}
