package calculator_template;


import javax.swing.*;
public class Calculator_Template {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
           CalculatorGUI_Template gui =  new CalculatorGUI_Template();
           gui.setVisible(true);
        });
    }
}
