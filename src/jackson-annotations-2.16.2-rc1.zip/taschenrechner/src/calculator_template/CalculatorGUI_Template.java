package calculator_template;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorGUI_Template extends JFrame implements ActionListener {
    private final JTextField display;
    private final CalculatorEngine_Template engine;

    public CalculatorGUI_Template() {
        setTitle("calculator_template");
        setSize(250, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        // Components
        display = new JTextField();
        engine = new CalculatorEngine_Template(this);

        // Layout
        setLayout(new BorderLayout());
        add(display, BorderLayout.NORTH);
        add(createButtonsPanel(), BorderLayout.CENTER);
    }

    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 4));

        String[] buttons = {
                "7", "8", "9", "/",
                "4", "5", "6", "*",
                "1", "2", "3", "-",
                "0", ".", "=", "+"
        };

        for (String text : buttons) {
            JButton button = new JButton(text);
            button.addActionListener(this);
            panel.add(button);
        }

        return panel;
    }

    public void updateDisplay(String value) {
        display.setText(value);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        engine.buttonClicked(e.getActionCommand());
    }
}
