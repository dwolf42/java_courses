package calculator_template;

public class CalculatorEngine_Template {
    private final CalculatorGUI_Template gui;

    private double currentNumber;
    private double previousNumber;
    private String operator;

    public CalculatorEngine_Template(CalculatorGUI_Template gui) {
        this.gui = gui;
        reset();
    }

    public void buttonClicked(String buttonText) {
        switch (buttonText) {
            case "+":
            case "-":
            case "*":
            case "/":
                setOperator(buttonText);
                break;
            case "=":
                calculateResult();
                break;
            default:
                updateCurrentNumber(buttonText);
                break;
        }
    }

    private void updateCurrentNumber(String value) {
        if (value.equals(".") && !containsDecimal(currentNumber)) {
            currentNumber = Double.parseDouble(currentNumber + value);
        } else if (!value.equals(".")) {
            currentNumber = Double.parseDouble(currentNumber + value);
        }
        gui.updateDisplay(String.valueOf(currentNumber));
    }

    private boolean containsDecimal(double num) {
        return String.valueOf(num).contains(".");
    }

    private void setOperator(String op) {
        previousNumber = currentNumber;
        currentNumber = 0;
        operator = op;
        gui.updateDisplay("");
    }

    private void calculateResult() {
        switch (operator) {
            case "+":
                currentNumber = previousNumber + currentNumber;
                break;
            case "-":
                currentNumber = previousNumber - currentNumber;
                break;
            case "*":
                currentNumber = previousNumber * currentNumber;
                break;
            case "/":
                currentNumber = previousNumber / currentNumber;
                break;
        }
        gui.updateDisplay(String.valueOf(currentNumber));
    }

    public void reset() {
        currentNumber = 0.0;
        previousNumber = 0.0;
        operator = "";
    }
}
