package approaches_cli_calc;

import java.util.LinkedList;
import java.util.Scanner;

/*
* # Simple calculator
* ## ~Class description~
* Input is read from keyboard, and evaluated if it's a number or character.
* Numbers are stored as string, so numbers and characters can be whitespace-out after processing, and removed afterward.
* */

// basic calculator finished 25.07.23 4:58 pm
// improved algorithm 26.07.23 10:27 am
// operator precedence 28.07.23 1:07 pm
// reusing result 28.07.23 1:45 pm

class Calc {
    public static void main(String[] args) {
        LinkedList<String> operands = new LinkedList<>();
        LinkedList<Character> operators = new LinkedList<>();

        Scanner scanner = new Scanner(System.in);
        String inp;

        while (true) {
            inp = scanner.nextLine().trim();
            if (inp.isEmpty()) {
                multiplicationOperationsOnLinkedLists(operands, operators);
                removeWhitespaceOfLinkedLists(operands, operators);
                additionOperationsOnLinkedLists(operands, operators);
                removeWhitespaceOfLinkedLists(operands, operators);
                printResult(operands);
                inp = scanner.nextLine().trim();
            }

            try {
                // ensure input is double
                operands.add(String.valueOf(Double.parseDouble(inp)));
            } catch (Exception e) {
                operators.add(inp.charAt(0));
            }
        }

    }

    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private static void multiplicationOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '*') {
                operands.set(i + 1, multiplyElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '/') {
                operands.set(i + 1, divideElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private static void additionOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '+') {
                operands.set(i + 1, addElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '-') {
                operands.set(i + 1, subtractElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // remove whitespace to shrink operators<> and operands<>
    private static void removeWhitespaceOfLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        operands.removeIf(item -> item.equals(" "));
        operators.removeIf(item -> item.equals(' '));
    }

    // evaluation if result is whole number or contains fraction
    // note: result is always cast to int, if fraction is 0 (e.g.: 10.0 + 1 is 11, instead of 11.0)
    /* credits: https://stackoverflow.com/a/6619392
     * $n = 1.25;
     * $whole = floor($n);      // 1
     * $fraction = $n - $whole; // .25
     * */
    private static void printResult(LinkedList<String> operands) {
        double whole = Math.floor(Double.parseDouble(operands.get(0)));
        double fraction = Double.parseDouble(operands.get(0)) - whole;
        if (fraction == 0) {
            System.out.println((int) Double.parseDouble(operands.get(0)));
        } else {
            System.out.println(Double.parseDouble(operands.get(0)));
        }
    }

    private static String multiplyElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) * Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String divideElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) / Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String addElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) + Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String subtractElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) - Double.parseDouble(val2);
        return String.valueOf(result);
    }
}
