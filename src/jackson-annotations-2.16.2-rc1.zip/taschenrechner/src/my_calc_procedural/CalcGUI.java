package my_calc_procedural;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

/*
 * # Advanced calculator with GUI
 * ## ~Class description~
 * Input is read from gui key pad, and evaluated by the exp4j library if needed.
 * */

// basic calculator finished 25.07.23 4:58 pm
// improved algorithm 26.07.23 10:27 am
// operator precedence 28.07.23 1:07 pm
// reusing result 28.07.23 1:45 pm
// GUI and calculator functions reworked 01.08. 1:53 pm
// GUI look and feel 01.08. 4:40 pm
// calculation improvements, fix decimal issues 07.08 12:34 pm
// Full OOP implementation 08.08. 12:49 pm

public class CalcGUI extends JFrame implements ActionListener {

    // Declare output field
    JTextField outputField;

    // Declare numeric buttons
    JButton buttonZero;
    JButton buttonOne;
    JButton buttonTwo;
    JButton buttonThree;
    JButton buttonFour;
    JButton buttonFive;
    JButton buttonSix;
    JButton buttonSeven;
    JButton buttonEight;
    JButton buttonNine;

    // Declare operator buttons
    JButton buttonDivide;
    JButton buttonMultiply;
    JButton buttonSubtract;
    JButton buttonAddition;

    // Declare misc buttons
    JButton buttonDecimal;
    JButton buttonEqual;
    JButton buttonCE;

    // Declare guiPanel
    JPanel guiPanel;

    // Input from GUI.
    // Also used for the evaluation/calculation
    String userInput = "";

    public CalcGUI() {
        // Instantiate mainFrame, set a title and a close action
        this.setTitle("calculator_template");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(316, 450);

        // Instantiate guiPanel
        guiPanel = new JPanel();
        guiPanel.setLayout(null);
        guiPanel.setBackground(new Color(255, 255, 255));

        // Add guiPanel to mainFrame, sort it and make visible
        this.add(guiPanel);

        /* ~ Row 1 ~ */
        // Text field
        Font font = new Font(Font.DIALOG_INPUT, Font.PLAIN, 20);
        outputField = new JTextField(16);
        outputField.setFont(font);
        outputField.setMaximumSize(new Dimension(199, 59));
        outputField.setDisabledTextColor(new Color(0, 0, 0));
        // margin space between the text field's border and its text
        outputField.setMargin(new Insets(2, 10, 2, 10));
        outputField.setText("");
        outputField.setBounds(20, 45, 204, 64);
        outputField.setEditable(false);
        outputField.setBackground(new Color(232, 232, 232));
        guiPanel.add(outputField);

        // CE button
        buttonCE = new JButton("CE");
        guiPanel.add(buttonCE);
        buttonCE.setBounds(230, 45, 64, 64);
        buttonCE.setBackground(new Color(252, 74, 3));
        buttonCE.setBorderPainted(true);
        buttonCE.addActionListener(this);


        /* ~ Row 2 ~ */
        // Button seven
        buttonSeven = new JButton("7");
        guiPanel.add(buttonSeven);
        buttonSeven.setBounds(20, 115, 64, 64);
        buttonSeven.setBackground(new Color(250, 238, 230));
        buttonSeven.setBorderPainted(true);
        buttonSeven.addActionListener(this);

        // Button eight
        buttonEight = new JButton("8");
        guiPanel.add(buttonEight);
        buttonEight.setBounds(90, 115, 64, 64);
        buttonEight.setBackground(new Color(250, 238, 230));
        buttonEight.setBorderPainted(true);
        buttonEight.addActionListener(this);

        // Button nine
        buttonNine = new JButton("9");
        guiPanel.add(buttonNine);
        buttonNine.setBounds(160, 115, 64, 64);
        buttonNine.setBackground(new Color(250, 238, 230));
        buttonNine.setBorderPainted(true);
        buttonNine.addActionListener(this);

        // Divide button
        buttonDivide = new JButton("/");
        guiPanel.add(buttonDivide);
        buttonDivide.setBounds(230, 115, 64, 64);
        buttonDivide.setBackground(new Color(158, 233, 247));
        buttonDivide.setBorderPainted(true);
        buttonDivide.addActionListener(this);


        /* ~ Row 3 ~ */
        // Button four
        buttonFour = new JButton("4");
        guiPanel.add(buttonFour);
        buttonFour.setBounds(20, 185, 64, 64);
        buttonFour.setBackground(new Color(250, 238, 230));
        buttonFour.setBorderPainted(true);
        buttonFour.addActionListener(this);

        // Button five
        buttonFive = new JButton("5");
        guiPanel.add(buttonFive);
        buttonFive.setBounds(90, 185, 64, 64);
        buttonFive.setBackground(new Color(250, 238, 230));
        buttonFive.setBorderPainted(true);
        buttonFive.addActionListener(this);

        // Button six
        buttonSix = new JButton("6");
        guiPanel.add(buttonSix);
        buttonSix.setBounds(160, 185, 64, 64);
        buttonSix.setBackground(new Color(250, 238, 230));
        buttonSix.setBorderPainted(true);
        buttonSix.addActionListener(this);

        // Multiply button
        buttonMultiply = new JButton("*");
        guiPanel.add(buttonMultiply);
        buttonMultiply.setBounds(230, 185, 64, 64);
        buttonMultiply.setBackground(new Color(158, 233, 247));
        buttonMultiply.setBorderPainted(true);
        buttonMultiply.addActionListener(this);


        /* ~ Row 4 ~ */
        // Button one
        buttonOne = new JButton("1");
        guiPanel.add(buttonOne);
        buttonOne.setBounds(20, 255, 64, 64);
        buttonOne.setBackground(new Color(250, 238, 230));
        buttonOne.setBorderPainted(true);
        buttonOne.addActionListener(this);

        // Button two
        buttonTwo = new JButton("2");
        guiPanel.add(buttonTwo);
        buttonTwo.setBounds(90, 255, 64, 64);
        buttonTwo.setBackground(new Color(250, 238, 230));
        buttonTwo.setBorderPainted(true);
        buttonTwo.addActionListener(this);

        // Button tree
        buttonThree = new JButton("3");
        guiPanel.add(buttonThree);
        buttonThree.setBounds(160, 255, 64, 64);
        buttonThree.setBackground(new Color(250, 238, 230));
        buttonThree.setBorderPainted(true);
        buttonThree.addActionListener(this);

        // Subtraction button
        buttonSubtract = new JButton("-");
        guiPanel.add(buttonSubtract);
        buttonSubtract.setBounds(230, 255, 64, 64);
        buttonSubtract.setBackground(new Color(158, 233, 247));
        buttonSubtract.setBorderPainted(true);
        buttonSubtract.addActionListener(this);


        /* ~ Row 5 ~ */
        // Button zero
        buttonZero = new JButton("0"); // Instantiate button
        guiPanel.add(buttonZero); // Add button to GUI
        buttonZero.setBounds(20, 325, 64, 64); // Dimensions
        buttonZero.setBackground(new Color(250, 238, 230));
        buttonZero.setBorderPainted(true);
        buttonZero.addActionListener(this); // ActionListener

        // Decimal button
        buttonDecimal = new JButton(".");
        guiPanel.add(buttonDecimal);
        buttonDecimal.setBounds(90, 325, 64, 64);
        buttonDecimal.setBackground(new Color(158, 233, 247));
        buttonDecimal.setBorderPainted(true);
        buttonDecimal.addActionListener(this);

        // Equal button
        buttonEqual = new JButton("=");
        guiPanel.add(buttonEqual);
        buttonEqual.setBounds(160, 325, 64, 64);
        buttonEqual.setBackground(new Color(158, 233, 247));
        buttonEqual.setBorderPainted(true);
        buttonEqual.addActionListener(this);

        // Addition button
        buttonAddition = new JButton("+");
        guiPanel.add(buttonAddition);
        buttonAddition.setBounds(230, 325, 64, 64);
        buttonAddition.setBackground(new Color(158, 233, 247));
        buttonAddition.setBorderPainted(true);
        buttonAddition.addActionListener(this);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        CalcGUI calc = new CalcGUI();
        calc.setVisible(true);
    }

    public void calculate(String input) {
        Expression expression = new ExpressionBuilder(input).build();
        // Evaluation is required, to avoid NumberFormatException from of missing "e" notation
        double evaluated = expression.evaluate();

        double whole = Math.floor(evaluated);
        double fraction = evaluated - whole;

        if (fraction == 0) {
            int toInt = (int) evaluated;
            userInput = String.valueOf(toInt);
            outputField.setText(userInput);
        } else {
            userInput = String.valueOf(evaluated);
            outputField.setText(userInput);
        }

    }

    // TODO:
    //  Layout improvements: https://stackoverflow.com/questions/33192692/calculator-cant-have-decimal

    public void actionPerformed(ActionEvent ae) {
        String buttonPressed = ((JButton) ae.getSource()).getText();

        switch (buttonPressed) {
            case "+":
            case "-":
            case "*":
            case "/":
                userInput = userInput.concat(" " + buttonPressed + " ");
                outputField.setText(userInput);
                break;
            case "=":
                calculate(userInput.replaceAll(" ", ""));
                break;
            case "CE":
                userInput = "";
                outputField.setText(userInput);
                break;
            default:
                userInput = userInput.concat(buttonPressed);
                outputField.setText(userInput);
                break;
        }
    }

}