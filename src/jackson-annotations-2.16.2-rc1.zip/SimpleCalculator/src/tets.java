import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;

public class tets {
    public static void main(String[] args) {
//        //// Numeric buttons////
//        // Button zero
//        buttonZero = new JButton("0"); // Instantiate button
//        guiPanel.add(buttonZero); // Add button to GUI
//        buttonZero.setBounds(20 + insets.left, 165 + insets.top, size.width, size.height); // Dimensions
//        buttonZero.addActionListener(this); // ActionListener
//
//        // Button one
//        buttonOne = new JButton("1");
//        guiPanel.add(buttonOne);
//        buttonOne.setBounds(20 + insets.left, 130 + insets.top, size.width, size.height);
//        buttonOne.addActionListener(this);
//
//        // Button two
//        buttonTwo = new JButton("2");
//        guiPanel.add(buttonTwo);
//        buttonTwo.setBounds(80 + insets.left, 130 + insets.top, size.width, size.height);
//        buttonTwo.addActionListener(this);
//
//        // Button tree
//        buttonThree = new JButton("3");
//        guiPanel.add(buttonThree);
//        buttonThree.setBounds(140 + insets.left, 130 + insets.top, size.width, size.height);
//        buttonThree.addActionListener(this);
//
//        // Button four
//        buttonFour = new JButton("4");
//        guiPanel.add(buttonFour);
//        buttonFour.setBounds(20 + insets.left, 95 + insets.top, size.width, size.height);
//        buttonFour.addActionListener(this);
//
//        // Button five
//        buttonFive = new JButton("5");
//        guiPanel.add(buttonFive);
//        buttonFive.setBounds(80 + insets.left, 95 + insets.top, size.width, size.height);
//        buttonFive.addActionListener(this);
//
//        // Button six
//        buttonSix = new JButton("6");
//        guiPanel.add(buttonSix);
//        buttonSix.setBounds(140 + insets.left, 95 + insets.top, size.width, size.height);
//        buttonSix.addActionListener(this);
//
//        // Button seven
//        buttonSeven = new JButton("7");
//        guiPanel.add(buttonSeven);
//        buttonSeven.setBounds(20 + insets.left, 60 + insets.top, size.width, size.height);
//        buttonSeven.addActionListener(this);
//
//        // Button eight
//        buttonEight = new JButton("8");
//        guiPanel.add(buttonEight);
//        buttonEight.setBounds(80 + insets.left, 60 + insets.top, size.width, size.height);
//        buttonEight.addActionListener(this);
//
//        // Button nine
//        buttonNine = new JButton("9");
//        guiPanel.add(buttonNine);
//        buttonNine.setBounds(140 + insets.left, 60 + insets.top, size.width, size.height);
//        buttonNine.addActionListener(this);
//
//        //// Operator buttons////
//        // Note: The equals '=' button is located under misc buttons, since button represents the result
//        // Divide button
//        buttonDivide = new JButton("/");
//        guiPanel.add(buttonDivide);
//        buttonDivide.setBounds(200 + insets.left, 60 + insets.top, size.width, size.height);
//        buttonDivide.addActionListener(this);
//
//        // Multiply button
//        buttonMultiply = new JButton("*");
//        guiPanel.add(buttonMultiply);
//        buttonMultiply.setBounds(200 + insets.left, 95 + insets.top, size.width, size.height);
//        buttonMultiply.addActionListener(this);
//
//        // Addition button
//        buttonAddition = new JButton("+");
//        guiPanel.add(buttonAddition);
//        buttonAddition.setBounds(200 + insets.left, 165 + insets.top, size.width, size.height);
//        buttonAddition.addActionListener(this);
//
//        // Subtraction button
//        buttonSubtract = new JButton("-");
//        guiPanel.add(buttonSubtract);
//        buttonSubtract.setBounds(200 + insets.left, 130 + insets.top, size.width, size.height);
//        buttonSubtract.addActionListener(this);
//
//        //// Misc Buttons////
//        // CE button
//        buttonCE = new JButton("CE");
//        guiPanel.add(buttonCE);
//        buttonCE.setBounds(200 + insets.left, 25 + insets.top, 7 + size.width, size.height);
//        buttonCE.addActionListener(this);
//
//        // Decimal button
//        buttonDecimal = new JButton(".");
//        guiPanel.add(buttonDecimal);
//        buttonDecimal.setBounds(80 + insets.left, 165 + insets.top, size.width, size.height);
//        buttonDecimal.addActionListener(this);
//
//        // Equal button
//        buttonEqual = new JButton("=");
//        guiPanel.add(buttonEqual);
//        buttonEqual.setBounds(140 + insets.left, 165 + insets.top, size.width, size.height);
//        buttonEqual.addActionListener(this);
//
//        //// Display ////
//        // Text field
//        outputField.setMaximumSize(new Dimension(200, 40));
//        outputField.setDisabledTextColor(new Color(0, 0, 0));
//        outputField.setMargin(insets);
//        outputField.setText(output.toString());
//        outputField.setBounds(20 + insets.left, 25 + insets.top, 120 + size.width, size.height);
//        outputField.setEditable(false);
//        guiPanel.add(outputField);
    }
}
