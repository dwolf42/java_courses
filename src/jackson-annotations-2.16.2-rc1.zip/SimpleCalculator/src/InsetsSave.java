
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class InsetsSave extends JFrame implements ActionListener {
        String output = "0";

        // Declare output field
        JTextField outputField;

        // Declare numeric buttons
        JButton buttonZero;
        JButton buttonOne;
        JButton buttonTwo;
        JButton buttonThree;
        JButton buttonFour;
        JButton buttonFive;
        JButton buttonSix;
        JButton buttonSeven;
        JButton buttonEight;
        JButton buttonNine;

        // Declare operator buttons
        JButton buttonDivide;
        JButton buttonMultiply;
        JButton buttonSubtract;
        JButton buttonAddition;

        // Declare misc buttons
        JButton buttonDecimal;
        JButton buttonEqual;
        JButton buttonCE;

        // Declare guiPanel
        JPanel guiPanel;

        public InsetsSave() {
            // Create mainFrame, set a title and a close action
            JFrame mainFrame = new JFrame();
            mainFrame.setTitle("Calculator");
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Instantiate numeric buttons
            buttonZero = new JButton("0");
            buttonOne = new JButton("1");
            buttonTwo = new JButton("2");
            buttonThree = new JButton("3");
            buttonFour = new JButton("4");
            buttonFive = new JButton("5");
            buttonSix = new JButton("6");
            buttonSeven = new JButton("7");
            buttonEight = new JButton("8");
            buttonNine = new JButton("9");

            // Instantiate operator buttons
            buttonDivide = new JButton("/");
            buttonMultiply = new JButton("*");
            buttonSubtract = new JButton("-");
            buttonAddition = new JButton("+");

            // Instantiate misc buttons
            buttonDecimal = new JButton(".");
            buttonEqual = new JButton("=");
            buttonCE = new JButton("CE");

            // Instantiate guiPanel
            guiPanel = new JPanel();
            guiPanel.setLayout(null);

            // Add numeric buttons
            guiPanel.add(buttonZero);
            guiPanel.add(buttonOne);
            guiPanel.add(buttonTwo);
            guiPanel.add(buttonThree);
            guiPanel.add(buttonFour);
            guiPanel.add(buttonFive);
            guiPanel.add(buttonSix);
            guiPanel.add(buttonSeven);
            guiPanel.add(buttonEight);
            guiPanel.add(buttonNine);

            // Add operator buttons
            guiPanel.add(buttonDivide);
            guiPanel.add(buttonMultiply);
            guiPanel.add(buttonSubtract);
            guiPanel.add(buttonAddition);
            guiPanel.add(buttonDecimal);

            // Add misc buttons
            guiPanel.add(buttonEqual);
            guiPanel.add(buttonCE);

            // Add guiPanel to mainFrame, sort it and make visible
            mainFrame.add(guiPanel);

            Insets insets = guiPanel.getInsets();

            // <Text field>
            outputField = new JTextField(16);

            outputField.setMaximumSize(new Dimension(185, 40));
            outputField.setDisabledTextColor(new Color(0, 0, 0));

            // Button dimensions
            Dimension size = buttonCE.getPreferredSize();

            outputField.setMargin(insets);
            outputField.setText(output);
            outputField.setBounds(20 + insets.left, 25 + insets.top, 120 + size.width, size.height);
            outputField.setEditable(false);
            guiPanel.add(outputField);

            buttonCE.setBounds(200 + insets.left, 25 + insets.top, size.width, size.height);

            buttonSeven.setBounds(20 + insets.left, 60 + insets.top, size.width, size.height);
            buttonEight.setBounds(80 + insets.left, 60 + insets.top, size.width, size.height);
            buttonNine.setBounds(140 + insets.left, 60 + insets.top, size.width, size.height);
            buttonDivide.setBounds(200 + insets.left, 60 + insets.top, size.width, size.height);

            buttonFour.setBounds(20 + insets.left, 95 + insets.top, size.width, size.height);
            buttonFive.setBounds(80 + insets.left, 95 + insets.top, size.width, size.height);
            buttonSix.setBounds(140 + insets.left, 95 + insets.top, size.width, size.height);
            buttonMultiply.setBounds(200 + insets.left, 95 + insets.top, size.width, size.height);

            buttonOne.setBounds(20 + insets.left, 125 + insets.top, size.width, size.height);
            buttonTwo.setBounds(80 + insets.left, 125 + insets.top, size.width, size.height);
            buttonThree.setBounds(140 + insets.left, 125 + insets.top, size.width, size.height);
            buttonSubtract.setBounds(200 + insets.left, 125 + insets.top, size.width, size.height);

            buttonZero.setBounds(20 + insets.left, 160 + insets.top, size.width, size.height);
            buttonDecimal.setBounds(80 + insets.left, 160 + insets.top, size.width, size.height);
            buttonEqual.setBounds(140 + insets.left, 160 + insets.top, size.width, size.height);
            buttonAddition.setBounds(200 + insets.left, 160 + insets.top, size.width, size.height);

            // Button ActionListener
            buttonCE.addActionListener(this);

            insets = mainFrame.getInsets();
            mainFrame.setSize(275 + insets.left + insets.right,
                    250 + insets.top + insets.bottom);

            mainFrame.setVisible(true);
        }

        public static void main(String[] args) {
            CalcGUI calc = new CalcGUI();
            calc.setVisible(true);


        }

        public void actionPerformed(ActionEvent ae) {


        }


    }

