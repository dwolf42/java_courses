package testing;

import java.util.LinkedList;

public class Test {
    static StringBuilder output = new StringBuilder();
    static String text;
    public static void main(String[] args) {
        LinkedList<String> operands = new LinkedList<>();
        operands.add("2.5");
        displayResult(operands);
        System.out.println(text);

    }
    private static void displayResult(LinkedList<String> operands) {
        double whole = Math.floor(Double.parseDouble(operands.get(0)));
        double fraction = Double.parseDouble(operands.get(0)) - whole;
        if (fraction == 0) {
            int toInt = Integer.parseInt(operands.get(0));
            output = new StringBuilder();
            output.append(toInt);
            System.out.println("if output: " + output);
            text = output.toString();
        } else {
            System.out.println(operands);
            output = new StringBuilder(operands.get(0));
            System.out.println("else output: " + output);
            text = output.toString();
        }
    }
}
