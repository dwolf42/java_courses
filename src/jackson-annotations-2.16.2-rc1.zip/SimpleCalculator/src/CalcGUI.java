import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.LinkedList;

// basic calculator finished 25.07.23 4:58 pm
// improved algorithm 26.07.23 10:27 am
// operator precedence 28.07.23 1:07 pm
// reusing result 28.07.23 1:45 pm
// GUI and calculator functions reworked 01.08. 1:53 pm
// GUI look and feel 01.08. 4:40 pm
public class CalcGUI extends JFrame implements ActionListener {
    boolean isDecimalPressed = false;
    StringBuilder output = new StringBuilder();

    // Declare output field
    JTextField outputField;

    // Declare numeric buttons
    JButton buttonZero;
    JButton buttonOne;
    JButton buttonTwo;
    JButton buttonThree;
    JButton buttonFour;
    JButton buttonFive;
    JButton buttonSix;
    JButton buttonSeven;
    JButton buttonEight;
    JButton buttonNine;

    // Declare operator buttons
    JButton buttonDivide;
    JButton buttonMultiply;
    JButton buttonSubtract;
    JButton buttonAddition;

    // Declare misc buttons
    JButton buttonDecimal;
    JButton buttonEqual;
    JButton buttonCE;

    // Declare guiPanel
    JPanel guiPanel;

    // Lists for calculation
    LinkedList<String> operands = new LinkedList<>();
    LinkedList<Character> operators = new LinkedList<>();


    public CalcGUI() {
        // Instantiate mainFrame, set a title and a close action
        this.setTitle("Calculator");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(316, 450);

        // Instantiate guiPanel
        guiPanel = new JPanel();
        guiPanel.setLayout(null);
        guiPanel.setBackground(new Color(255, 255, 255));

        // Add guiPanel to mainFrame, sort it and make visible
        this.add(guiPanel);

        /* ~ Row 1 ~ */
        // Text field
        Font font = new Font(Font.DIALOG_INPUT, Font.PLAIN, 20);
        outputField = new JTextField(16);
        outputField.setFont(font);
        outputField.setMaximumSize(new Dimension(199, 59));
        outputField.setDisabledTextColor(new Color(0, 0, 0));
        // margin space between the text field's border and its text
        outputField.setMargin(new Insets(2, 10, 2, 10));
        outputField.setText(output.toString());
        outputField.setBounds(20, 45, 204, 64);
        outputField.setEditable(false);
        outputField.setBackground(new Color(232, 232, 232));
        guiPanel.add(outputField);

        // CE button
        buttonCE = new JButton("CE");
        guiPanel.add(buttonCE);
        buttonCE.setBounds(230, 45, 64, 64);
        buttonCE.setBackground(new Color(252, 74, 3));
        buttonCE.setBorderPainted(true);
        buttonCE.addActionListener(this);


        /* ~ Row 2 ~ */
        // Button seven
        buttonSeven = new JButton("7");
        guiPanel.add(buttonSeven);
        buttonSeven.setBounds(20, 115, 64, 64);
        buttonSeven.setBackground(new Color(250, 238, 230));
        buttonSeven.setBorderPainted(true);
        buttonSeven.addActionListener(this);

        // Button eight
        buttonEight = new JButton("8");
        guiPanel.add(buttonEight);
        buttonEight.setBounds(90, 115, 64, 64);
        buttonEight.setBackground(new Color(250, 238, 230));
        buttonEight.setBorderPainted(true);
        buttonEight.addActionListener(this);

        // Button nine
        buttonNine = new JButton("9");
        guiPanel.add(buttonNine);
        buttonNine.setBounds(160, 115, 64, 64);
        buttonNine.setBackground(new Color(250, 238, 230));
        buttonNine.setBorderPainted(true);
        buttonNine.addActionListener(this);

        // Divide button
        buttonDivide = new JButton("/");
        guiPanel.add(buttonDivide);
        buttonDivide.setBounds(230, 115, 64, 64);
        buttonDivide.setBackground(new Color(158, 233, 247));
        buttonDivide.setBorderPainted(true);
        buttonDivide.addActionListener(this);


        /* ~ Row 3 ~ */
        // Button four
        buttonFour = new JButton("4");
        guiPanel.add(buttonFour);
        buttonFour.setBounds(20, 185, 64, 64);
        buttonFour.setBackground(new Color(250, 238, 230));
        buttonFour.setBorderPainted(true);
        buttonFour.addActionListener(this);

        // Button five
        buttonFive = new JButton("5");
        guiPanel.add(buttonFive);
        buttonFive.setBounds(90, 185, 64, 64);
        buttonFive.setBackground(new Color(250, 238, 230));
        buttonFive.setBorderPainted(true);
        buttonFive.addActionListener(this);

        // Button six
        buttonSix = new JButton("6");
        guiPanel.add(buttonSix);
        buttonSix.setBounds(160, 185, 64, 64);
        buttonSix.setBackground(new Color(250, 238, 230));
        buttonSix.setBorderPainted(true);
        buttonSix.addActionListener(this);

        // Multiply button
        buttonMultiply = new JButton("*");
        guiPanel.add(buttonMultiply);
        buttonMultiply.setBounds(230, 185, 64, 64);
        buttonMultiply.setBackground(new Color(158, 233, 247));
        buttonMultiply.setBorderPainted(true);
        buttonMultiply.addActionListener(this);


        /* ~ Row 4 ~ */
        // Button one
        buttonOne = new JButton("1");
        guiPanel.add(buttonOne);
        buttonOne.setBounds(20, 255, 64, 64);
        buttonOne.setBackground(new Color(250, 238, 230));
        buttonOne.setBorderPainted(true);
        buttonOne.addActionListener(this);

        // Button two
        buttonTwo = new JButton("2");
        guiPanel.add(buttonTwo);
        buttonTwo.setBounds(90, 255, 64, 64);
        buttonTwo.setBackground(new Color(250, 238, 230));
        buttonTwo.setBorderPainted(true);
        buttonTwo.addActionListener(this);

        // Button tree
        buttonThree = new JButton("3");
        guiPanel.add(buttonThree);
        buttonThree.setBounds(160, 255, 64, 64);
        buttonThree.setBackground(new Color(250, 238, 230));
        buttonThree.setBorderPainted(true);
        buttonThree.addActionListener(this);

        // Subtraction button
        buttonSubtract = new JButton("-");
        guiPanel.add(buttonSubtract);
        buttonSubtract.setBounds(230, 255, 64, 64);
        buttonSubtract.setBackground(new Color(158, 233, 247));
        buttonSubtract.setBorderPainted(true);
        buttonSubtract.addActionListener(this);


        /* ~ Row 5 ~ */
        // Button zero
        buttonZero = new JButton("0"); // Instantiate button
        guiPanel.add(buttonZero); // Add button to GUI
        buttonZero.setBounds(20, 325, 64, 64); // Dimensions
        buttonZero.setBackground(new Color(250, 238, 230));
        buttonZero.setBorderPainted(true);
        buttonZero.addActionListener(this); // ActionListener

        // Decimal button
        buttonDecimal = new JButton(".");
        guiPanel.add(buttonDecimal);
        buttonDecimal.setBounds(90, 325, 64, 64);
        buttonDecimal.setBackground(new Color(158, 233, 247));
        buttonDecimal.setBorderPainted(true);
        buttonDecimal.addActionListener(this);

        // Equal button
        buttonEqual = new JButton("=");
        guiPanel.add(buttonEqual);
        buttonEqual.setBounds(160, 325, 64, 64);
        buttonEqual.setBackground(new Color(158, 233, 247));
        buttonEqual.setBorderPainted(true);
        buttonEqual.addActionListener(this);

        // Addition button
        buttonAddition = new JButton("+");
        guiPanel.add(buttonAddition);
        buttonAddition.setBounds(230, 325, 64, 64);
        buttonAddition.setBackground(new Color(158, 233, 247));
        buttonAddition.setBorderPainted(true);
        buttonAddition.addActionListener(this);

        this.setVisible(true);

    }

    public static void main(String[] args) {
        CalcGUI calc = new CalcGUI();
        calc.setVisible(true);
    }

    public void calculate(String inp) {
        if (inp.equals(".") || inp.equals("CE")) {
            return;
        }
        if (inp.equals("=")) {
            multiplicationOperationsOnLinkedLists(operands, operators);
            removeWhitespaceOfLinkedLists(operands, operators);
            additionOperationsOnLinkedLists(operands, operators);
            removeWhitespaceOfLinkedLists(operands, operators);
            displayResult(operands);
            return; // This tiny guy makes the program "wait" for another input.
        }
        try {
            // ensure input is double
            operands.add(String.valueOf(Double.parseDouble(inp)));
        } catch (Exception e) {
            operators.add(inp.charAt(0));
        }
    }

    public void actionPerformed(ActionEvent ae) {
        String buttonPressed = ((JButton) ae.getSource()).getText();
        switch (buttonPressed) {
            case "0":
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
            case "6":
            case "7":
            case "8":
            case "9":
                if (isDecimalPressed) {
                    double buttonPressedToDouble = Double.parseDouble(buttonPressed);
                    buttonPressedToDouble /= 10;
                    double lastOperandsToDouble = Double.parseDouble(operands.get(operands.size() - 1));
                    lastOperandsToDouble += buttonPressedToDouble;
                    operands.set(operands.size() - 1, String.valueOf(lastOperandsToDouble)); // set the last entry of operands to toS
                    output.append(buttonPressed);
                    outputField.setText(output.toString());
                    isDecimalPressed = false;
                    calculate(operands.get(operands.size() - 1));
                    break;
                } else {

                    output.append(buttonPressed);
                    outputField.setText(output.toString());
                    calculate(buttonPressed);
                    break;
                }
            case "+":
            case "-":
            case "*":
            case "/":
                output.append(" ");
                output.append(buttonPressed);
                output.append(" ");
                outputField.setText(output.toString());
                calculate(buttonPressed);
                break;
            case ".":
                isDecimalPressed = true;
                output.append(".");
                outputField.setText(output.toString());
                calculate(buttonPressed);
                break;
            case "=":
                calculate("=");
                break;
            case "CE":
                output = new StringBuilder();
                outputField.setText(output.toString());
                operators.clear();
                operands.clear();
                calculate(buttonPressed);
            default:
                break;
        }
    }


    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private void multiplicationOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '*') {
                operands.set(i + 1, multiplyElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '/') {
                operands.set(i + 1, divideElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private void additionOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '+') {
                operands.set(i + 1, addElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '-') {
                operands.set(i + 1, subtractElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // remove whitespace to shrink operators<> and operands<>
    private void removeWhitespaceOfLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        operands.removeIf(item -> item.equals(" "));
        operators.removeIf(item -> item.equals(' '));
    }

    // evaluation if result is whole number or contains fraction
    // note: result is always cast to int, if fraction is 0 (e.g.: 10.0 + 1 is 11, instead of 11.0)
    /* credits: https://stackoverflow.com/a/6619392
     * $n = 1.25;
     * $whole = floor($n);      // 1
     * $fraction = $n - $whole; // .25
     * */
    private void displayResult(LinkedList<String> operands) {
        double whole = Math.floor(Double.parseDouble(operands.get(0)));
        double fraction = Double.parseDouble(operands.get(0)) - whole;
        if (fraction == 0) {
            double d = Double.parseDouble(operands.get(0));
            int toInt = (int) d;
            output = new StringBuilder();
            output.append(toInt);
            outputField.setText(output.toString());
        } else {
            output = new StringBuilder(operands.get(0));
            outputField.setText(output.toString());
        }
    }

    private static String multiplyElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) * Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String divideElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) / Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String addElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) + Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String subtractElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) - Double.parseDouble(val2);
        return String.valueOf(result);
    }

}