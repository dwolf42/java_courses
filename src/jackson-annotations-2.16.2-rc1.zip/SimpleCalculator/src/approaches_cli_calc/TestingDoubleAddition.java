package approaches_cli_calc;

public class TestingDoubleAddition {
    public static void main(String[] args) {

    }
}
