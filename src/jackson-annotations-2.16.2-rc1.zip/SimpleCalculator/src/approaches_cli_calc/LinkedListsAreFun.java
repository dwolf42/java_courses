package approaches_cli_calc;

import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;

public class LinkedListsAreFun {
    public static void main(String[] args) {
        String inp = "1+3-5*7/8";
        char[] charArrOfInp = inp.toCharArray();
        LinkedList<String> inpAsLinkedList = new LinkedList<String>();
        for (char ch : charArrOfInp) {
            inpAsLinkedList.add(String.valueOf(ch));
        }

        for (String str : inpAsLinkedList) {
            System.out.print(str + " ");
        }
        System.out.println(" ");

        inpAsLinkedList.pop();

        for (String str : inpAsLinkedList) {
            System.out.print(str + " ");
        }

//        List input = new LinkedList();
//        input.add("David");
//        input.add(37);
//
//        System.out.println("LinkedList content: " + input);
    }
}
