package approaches_cli_calc;

import java.util.LinkedList;
import java.util.Scanner;

public class TwoArraysApproach {
    public static void main(String[] args) {
        // 7.5*1+3+5*7/8+9-6

        // index % 2 = 0
        // index and index + 1
        //  0   1  2  3  4  5  6  7  8  9  10 11 12 13 14
        //[7.5, 1, 3, 5, 7, 8, 9, 6]
        // while this is String, it must only contain double for calculations
        LinkedList<String> operands = new LinkedList<String>();
        operands.add("7.5");
        operands.add("1");
        operands.add("3");
        operands.add("5");
        operands.add("7");
        operands.add("8");
        operands.add("9");
        operands.add("6");

        // index % 2 != 0
        //  0  1  2  3  4  5  6  7  8  9 10 11 12 13 14
        // [*, +, +, *, /, +, -]
        LinkedList<Character> operators = new LinkedList<Character>();
        operators.add('*');
        operators.add('+');
        operators.add('+');
        operators.add('*');
        operators.add('/');
        operators.add('+');
        operators.add('-');

        Scanner scanner = new Scanner(System.in);
        String inp;
        multiplicationOperationsOnLinkedLists(operands, operators);
        removeWhitespaceOfLinkedLists(operands, operators);
        additionOperationsOnLinkedLists(operands, operators);
        removeWhitespaceOfLinkedLists(operands, operators);
        printResult(operands);
//        while (true) {
//            inp = scanner.nextLine().trim();
//            if (inp.isEmpty()) {
//                multiplicationOperationsOnLinkedLists(operands, operators);
//                removeWhitespaceOfLinkedLists(operands, operators);
//                additionOperationsOnLinkedLists(operands, operators);
//                removeWhitespaceOfLinkedLists(operands, operators);
//                printResult(operands);
//                break;
//            }
//
//            try {
//                // ensure input is double
//                double temp = Double.parseDouble(inp);
//                operands.add(inp);
//            } catch (Exception e) {
//                operators.add(inp.charAt(0));
//            }
//            break;
//        }

    }

    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private static void multiplicationOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '*') {
                operands.set(i + 1, multiplyElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '/') {
                operands.set(i + 1, divideElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // Iterates over operators<> and operands<> to perform multiplications.
    // Results are written to the index of the right operand.
    // Left operand will be replaced by whitespace.
    private static void additionOperationsOnLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        for (int i = 0; i < operators.size(); i++) {
            if (operators.get(i) == '+') {
                operands.set(i + 1, addElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
            if (operators.get(i) == '-') {
                operands.set(i + 1, subtractElementsOfLinkedLists(operands.get(i), operands.get(i + 1)));
                operands.set(i, " ");
                operators.set(i, ' ');
            }
        }
    }

    // remove whitespace to shrink operators<> and operands<>
    private static void removeWhitespaceOfLinkedLists(LinkedList<String> operands, LinkedList<Character> operators) {
        operands.removeIf(item -> item.equals(" "));
        operators.removeIf(item -> item.equals(' '));
    }

    private static void printResult(LinkedList<String> operands) {
        double whole = Math.floor(Double.parseDouble(operands.get(0)));
        double fraction = Double.parseDouble(operands.get(0)) - whole;
        if (fraction == 0) {
            System.out.println(Integer.parseInt(operands.get(0)));
        } else {
            System.out.println(Double.parseDouble(operands.get(0)));
        }
    }

    private static String multiplyElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) * Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String divideElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) / Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String addElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) + Double.parseDouble(val2);
        return String.valueOf(result);
    }

    private static String subtractElementsOfLinkedLists(String val1, String val2) {
        double result = Double.parseDouble(val1) - Double.parseDouble(val2);
        return String.valueOf(result);
    }
}