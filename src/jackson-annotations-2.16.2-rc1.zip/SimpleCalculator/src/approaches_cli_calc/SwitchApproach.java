package approaches_cli_calc;

import java.util.Scanner;
class SwitchApproach {
    private static String operator;
    private static int val1;
    private static int val2;
    private static int result;

    public static void main(String[] args) {
        run();
    }

    private static void run() {
        getValue();
        getOperator();
    }
    private static void getValue() {
        System.out.print("Enter value: ");
        val1 = new Scanner(System.in).nextInt();
    }

    private static void getOperator() {
        System.out.print("Input operator or hit enter for result: ");
        operator = new Scanner(System.in).nextLine();
        switch (operator) {
            case "+":
                addition();
                break;

            case "-":

                break;

            case "*":

                break;

            case "/":

                break;

            default:
                System.out.println(result);
        }
    }

    private static void addition() {
//        result = val1 + getValue(); -> I overcomplicated things
        result = val1 + val2;
        System.out.println(result);
        getOperator();
    }

}


