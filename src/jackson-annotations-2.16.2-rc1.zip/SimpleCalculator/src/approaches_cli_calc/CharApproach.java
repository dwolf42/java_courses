package approaches_cli_calc;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;

public class CharApproach {
    public static void main(String[] args) {
        String inp = "7.5*1+3+5*7/8+9-6";

        // inp.replaceAll("[+\\-*/]"," ");
        String digitsOfInp = inp.replaceAll("[+\\-*/]"," ");
        //  0    1  2  3  4  5  6  7
        // [7.5, 1, 3, 5, 7, 8, 9, 6]

        //  0  1 2 3 4 5 6 7 8 9 10 11 12 13 14
        // 7.5 * 1 + 3 + 5 * 7 /  8  +  9  -  6"
        String[] digitOfInpArr = digitsOfInp.split(" ");

        // raw LinkedList
        LinkedList inpLinkedList = new LinkedList();

//        // populate inpLinkedList
//        for (char ch : inpChar) {
//            inpLinkedList.add(ch);
//        }

        // print inpLinkedList
        for (int i = 0; i < inpLinkedList.size(); i++) {
            System.out.print(inpLinkedList.get(i) + " ");
        }

//        // try to convert elements of inpLinkedList to double
//        for (int i = 0; i < inpLinkedList.size(); i++) {
//            try {
//                inpLinkedList.get(i) = ;
//            } catch (Exception e){
//            }
//        }


//        for (int i = 0; i < inpLinkedList.size(); i++) {
//            if (inpLinkedList.get(i).equals("*")) {
//                inpLinkedList.get(i - 1) = inpLinkedList.get(i - 1) * inpLinkedList.get(i + 1);
//            }
//        }

    }
}
