package approaches_cli_calc;

import java.util.Scanner;

public class TestingDoubleBehavior {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        int ints = 0;
        double doubles = 0;


        try {
            ints = Integer.parseInt(input);
        } catch (Exception e) {
            doubles = Double.parseDouble(input);
        }

        System.out.println("ints: " + ints);
        System.out.println("doubles: " + doubles);

//        int numx = Integer.parseInt(scanner.nextLine());
//        double num = scanner.nextDouble();
//        double num2 = scanner.nextDouble();
//        int result = (int)num + (int)num2;
//        System.out.println(result);
    }
}
