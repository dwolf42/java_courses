package approaches_cli_calc;

import java.util.Scanner;
public class WhileApproach {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int val1;
        int val2;
        int result;
        String operator;

        while (scanner.hasNextDouble()) {
            System.out.println("yep");
            scanner.close();
        }
        System.out.println("nope");

    }

}


