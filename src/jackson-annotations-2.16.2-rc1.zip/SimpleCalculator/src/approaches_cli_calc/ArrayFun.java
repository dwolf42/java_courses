package approaches_cli_calc;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class ArrayFun {
    public static void main(String[] args) {

//        String inp = "1-3+5*7/8+9";
        String inp = "7*1+3+5*7/8+9-6";
//        String operatorPattern = "[-+*/]";
//        String operandsPattern = "[(0-9)]";
//        String inp = "7+1";

        // remove all digits
        inp = inp.replaceAll("[0-9]", "");

        String[] operands = inp.split("\\s");
//        String[] operands = inp.split("[0-9]");
//        String[] operators = inp.split("[+\\-*/]");

        System.out.println(Arrays.toString(operands));
//        System.out.println(Arrays.toString(operators));


//        int countOperators = 0;
//        int countOperands = 0;

//        for (int i = 0; i < inp.length(); i++) {
//            if (String.valueOf(inp.charAt(i)).matches(operatorPattern)) {
//                countOperators++;
//            } else {
//                countOperands++;
//            }
//        }
//
//        String[] operators = new String[countOperators];
//        for (int i = 0; i < inp.length(); i++) {
//            if (String.valueOf(inp.charAt(i)).matches(operatorPattern)) {
//                operators[i] = String.valueOf(inp.charAt(i));
//            }
//        }
//
//        String[] operands = new String[countOperands];
//        for (int i = 0; i < inp.length(); i++) {
//            if (String.valueOf(inp.charAt(i)).matches(operandsPattern)) {
//                operands[i] = String.valueOf(inp.charAt(i));
//            }
//        }


//        String[] ops = new String[inp.length()];
//        for (int i = 0; i < inp.length(); i++) {
//            if (inp[i].matches(opsPattern)) {
//
//            }
//        }


//        String[] operators = inp.split("[-+*/]");
//        String[] operands = inp.split("[(0-9)]");



//        List<String> listOfInp = new ArrayList <String>();
//        int listSize = listOfInp.size();
//
//        String[] arrOfInp = new String[] {inp};
//        System.out.println(Arrays.toString(arrOfInp));
//
//        String trimmedInp = inp.trim();
//        String replacedInp = trimmedInp.replaceAll("\\s", "");
//        String[] operators = replacedInp.split("[-+*/]");
//        String[] operands = replacedInp.split("[(0-9)]");
//        System.out.println(Arrays.toString(operators));
//        System.out.println(Arrays.toString(operands));


    }
}
