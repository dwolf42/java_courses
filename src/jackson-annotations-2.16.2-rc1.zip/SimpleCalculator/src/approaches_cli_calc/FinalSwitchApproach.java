package approaches_cli_calc;

import java.util.Scanner;

// basic calculator finished 25.07.23 4:58 pm
// improved algorithm 26.07.23 10:27 am

class FinalSwitchApproach {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputFromUser;
        String arithmeticOperatorFromUser;
        String regexPatternIntDouble = "^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$";

        double val1 = 0;

        while (true) {
            inputFromUser = scanner.nextLine();

            if (inputFromUser.matches(regexPatternIntDouble)) {
                val1 = Double.parseDouble(inputFromUser);
            }

            arithmeticOperatorFromUser = inputFromUser;

            switch (arithmeticOperatorFromUser) {
                case "+":
                    val1 = addition(val1, Double.parseDouble(scanner.nextLine()));
                    break;
                case "-":
                    val1 = subtraction(val1, Double.parseDouble(scanner.nextLine()));
                    break;
                case "*":
                    val1 = multiplication(val1, Double.parseDouble(scanner.nextLine()));
                    break;
                case "/":
                    val1 = division(val1, Double.parseDouble(scanner.nextLine()));
                    break;
                default:
                    // hitting enter will display result
                    /* credits: https://stackoverflow.com/a/6619392
                     * $n = 1.25;
                     * $whole = floor($n);      // 1
                     * $fraction = $n - $whole; // .25
                     * */
                    if (inputFromUser.isEmpty()) {
                        double whole = Math.floor(val1);
                        double fraction = val1 - whole;
                        if (fraction == 0) {
                            System.out.println((int) val1);
                        } else {
                            System.out.println(val1);
                        }
                        break;
                    }
            }
        }

    }

    private static double addition(double val1, double val2) {
        return val1 + val2;
    }

    private static double subtraction(double val1, double val2) {
        return val1 - val2;
    }

    private static double multiplication(double val1, double val2) {
        return val1 * val2;
    }

    private static double division(double val1, double val2) {
        return val1 / val2;
    }

}
