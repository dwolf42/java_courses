package approaches_cli_calc;

import java.util.Scanner;

public class ParseApproach {
    public static void main(String[] args) {

        String operator;
        double val1;
        double val2;
        double resultDouble = 0;
        int resultInt;
        Scanner scanner = new Scanner(System.in);
        String input;

        while (true) {

            input = scanner.nextLine().trim();

            // hitting enter will display result
            if (input.isEmpty()) {
                try {
                    String resultString = Double.toString(resultDouble);
                    resultInt = Integer.parseInt(resultString);
                    System.out.println("Result is int: " + resultInt);
                } catch (Exception e) {
//                    resultDouble = Double.parseDouble(input);
                    System.out.println("Result is double: " + resultDouble);
                }
                break;
            }

            val1 = Double.parseDouble(input);

            operator = scanner.nextLine();
            switch (operator) {
                case "+":
                    input = scanner.nextLine().trim();
                    val2 = Double.parseDouble(input);
                    resultDouble = addition(val1, val2);
                    break;

                case "-":

                    break;

                case "*":

                    break;

                case "/":

                    break;

                default:
                    System.out.println("Error!");
            }


        }

    }


    private static double addition(double val1, double val2) {
        return val1 + val2;
    }

}
