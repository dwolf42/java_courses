import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
public class Calculator {
    public int add(int first, int second) {
        return first + second;
    }
}
