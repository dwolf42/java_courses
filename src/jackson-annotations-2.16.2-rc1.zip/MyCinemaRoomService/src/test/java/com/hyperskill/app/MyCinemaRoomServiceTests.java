package com.hyperskill.app;

import ch.qos.logback.classic.util.ClassicEnvUtil;
import com.hyperskill.app.configuration.CinemaConfiguration;
import com.hyperskill.app.model.Seats;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

// TODO:
//  - test for CinemaRoomController:
//    + does getRoom return cinemaRoom?
//    + are the returned values correct?
//  - test for CinemaConfiguration:
//    does createRoom correctly return a room of 9x9 with a list of seats 9x9?
//    does createSeats correctly return seats with arbitrary values for seatRow and seatColumn?
//    does createRoom correctly return rooms with arbitrary values for roomRows and roomColumns?
//    do the int-define-beans return the correct values?

@SpringBootTest
class MyCinemaRoomServiceTests {

    // Tests if Seats Class correctly returns a seats object, having the defined variables
    @Test
    void seatsUnderTest() {
        int row = 10;
        int col = 10;
        Seats seatsTest = new Seats(row, col);

        Assertions.assertEquals(row, seatsTest.getRow());
        Assertions.assertEquals(col, seatsTest.getColumn());
    }

    @Test
    void cinemaConfigurationCreateSeatsUnterTest() {
        int row = 5;
        int col = 5;
        int amountOfSeats = row * col;
        CinemaConfiguration cinemaConfigurationTest = new CinemaConfiguration();
        List<Seats> createSeatTest = cinemaConfigurationTest.createSeats(row, col);

        // Test how many seats are in there
        Assertions.assertEquals(amountOfSeats,
                createSeatTest.size());


//        Assertions.assertTrue(seatsTest.size() >= lower && seatsTest.size() <= upper);
//        Assertions.assertTrue(seatsTest.get(seatsTest.size() - 1).getRow() >= lower
//                && seatsTest.get(seatsTest.size() - 1).getRow() <= upper);
//        Assertions.assertTrue(seatsTest.get(seatsTest.size() - 1).getColumn() >= lower
//                && seatsTest.get(seatsTest.size() - 1).getColumn() <= upper);
    }

//    @Test
//    void roomUnderTest() {
//        List<Seats> seatsTest = new ArrayList<>();
//        for (int i = 1; i <= quantitySeats; i++) {
//            seatsTest.add(new Seats(row, col));
//        }
//
//        Room roomTest = new Room(row, col, new ArrayList<>(
//                Arrays.asList(
//                        new Seats(row, col),
//                        new Seats(row, col),
//                        new Seats(row, col),
//                        new Seats(row, col),
//                        new Seats(row, col)
//                )) {
//        });
//    }

//
//        Assertions.assertEquals(row, roomTest.getRows());
//        Assertions.assertEquals(col, roomTest.getRows());
//        Assertions.assertEquals(quantityOfSeats, roomTest.getSeats().size());
//        Assertions.assertEquals(col, roomTest.getRows());
//
//
//    }
//
//
//    @Test
//    void cinemaRoomControllerUnderTest() {
//
//
//        Assertions.assertNotNull(cinemaRoomControllerTest.getRoom());
//        Assertions.assertEquals(row, cinemaRoomControllerTest.getRoom().getRows());
//        Assertions.assertEquals(col, cinemaRoomControllerTest.getRoom().getColumns());
//        Assertions.assertEquals(quantitySeats, cinemaRoomControllerTest.getRoom().getSeats().size());
//    }
//
//
//    // Seats tests
//    @Test
//    void ciemaRoomControllerSeatsRowsTest() {
//        assertThat(seatsTest.get(seatsTest.size() - 1).getRow()).isEqualTo(9);
//    }
//
//    @Test
//    void cinemaRoomcontrollerSeatsColumnTest() {
//        assertThat(seatsTest.get(seatsTest.size() - 1).getRow()).isEqualTo(9);
//        assertThat(seatsTest.get(seatsTest.size() - 1).getRow()).isEqualTo(9);
//    }
//
//    // Room test
//    @Test
//    void roomTest() {
//        final int rows = 7;
//        final int columns = 7;
//        List<Seats> availableSeats = new ArrayList<>();
//        for (int i = 1; i <= rows; i++) {
//            for (int j = 1; j <= columns; j++) {
//                availableSeats.add(new Seats(i, j));
//            }
//        }
//        Room roomTest = new Room(rows, columns, availableSeats);
//        assertThat(roomTest.
//                getRows())
//                .isEqualTo(rows);
//    }

    }
//    @Test
//    void cinemaConfigurationCreateRoomUnderTest() {
//        Assertions.assertEquals(9, cinemaRoom.getRows());
//        Assertions.assertEquals(9, cinemaRoom.getColumns());
//        Assertions.assertEquals(81, cinemaRoom.getSeats().size());
//
//    }
//

