package jackson_serialization_deserialization.deserialization;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

class Main {
    public static void main(String[] args) throws JsonProcessingException {
        singleObject();
        listOfObjects();
    }

    public static void singleObject() throws JsonProcessingException {
        // Create a post with some data.
        Post post = new Post(
                1,
                new Date(),
                "I learned how to use Jackson!",
                10,
                Arrays.asList("Well done!", "Great job!")
        );

        ObjectMapper objectMapper = new ObjectMapper();
        String postAsString = objectMapper.writeValueAsString(post);
        System.out.println(postAsString + "\n");

        // deserialized

        // here the serialized string is mapped to class again
        Post poster = objectMapper.readValue(postAsString,
                Post.class);

        poster.setContent("You got it !!");
        System.out.println(poster.getContent() + "\n");
    }

    public static void listOfObjects() throws JsonProcessingException {
        // Serialization of Lists of objects
        List<Post> postsList = List.of(
                new Post(1, new Date(), "Content1", 10, Arrays.asList("Comment1", "Comment2")),
                new Post(2, new Date(), "Content2", 42, Arrays.asList("Comment3", "Comment4"))
        );

        ObjectMapper objectMapper = new ObjectMapper();
        String postsAsJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(postsList);
        System.out.println(postsAsJson + "\n");

        // Deserialization of Lists of objects
        List<Post> deserializedPosts = objectMapper.readValue(postsAsJson, List.class);
        System.out.println(deserializedPosts.get(0).getContent());
    }
}