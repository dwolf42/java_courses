package com.hyperskill.app.contoller;

import com.hyperskill.app.model.Room;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CinemaRoomController {
    // Since there already is an instance of Room created in CinemaConfiguration, this Room instance
    // must be injected here
    private final Room cinemaRoom;

    // Spring favors convention over configuration. If there is only one constructor Spring assumes that
    // this constructor must be used for dependency injection. It is the reason why no @Autowired must be used in this constructor.
    public CinemaRoomController(Room cinemaRoom) {
        this.cinemaRoom = cinemaRoom;
    }

    @GetMapping("/seats")
    public Room getRoom() {
        return cinemaRoom;
    }
}
