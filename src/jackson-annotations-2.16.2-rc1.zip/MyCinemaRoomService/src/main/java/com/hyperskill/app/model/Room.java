package com.hyperskill.app.model;

import java.util.List;

public class Room {
    private int rows;
    private int columns;
    private List<Seats> availableSeats;

    public Room(int rows, int columns, List<Seats> seats) {
        this.rows = rows;
        this.columns = columns;
        this.availableSeats = seats;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }

    public List<Seats> getSeats() {
        return availableSeats;
    }

    public void setSeats(List<Seats> seats) {
        this.availableSeats = seats;
    }

}
