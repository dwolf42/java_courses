package com.hyperskill.app.configuration;

import com.hyperskill.app.model.Room;
import com.hyperskill.app.model.Seats;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class CinemaConfiguration {
    // In this class are multiple int-beans, and to help Spring decide, which of them to inject the @Qualifier is required.
    @Bean
    public List<Seats> createSeats(@Qualifier("defineSeatRow") int seatRow,
                                   @Qualifier("defineSeatColumn") int seatColumn) {
        List<Seats> seats = new ArrayList<>();
        for (int i = 1; i <= seatRow; i++) {
            for (int j = 1; j <= seatColumn; j++) {
                seats.add(new Seats(i, j));
            }
        }

        return seats;
    }

    // Different from the int-beans there is only one List-bean, so @Autowired is required.
    @Bean
    public Room createRoom(@Qualifier("defineRoomRows") int roomRows,
                           @Qualifier("defineRoomColumns") int roomColumns,
                           @Autowired List<Seats> seats) {

        return new Room(roomRows, roomColumns, seats);
    }

    @Bean
    public int defineSeatRow() {
        return 9;
    }

    @Bean
    public int defineSeatColumn() {
        return 9;
    }

    @Bean
    public int defineRoomRows() {
        return 9;
    }

    @Bean
    public int defineRoomColumns() {
        return 9;
    }
}
