package com.seleniumexpress.hellospringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan
@EnableAutoConfiguration
public class StarterApp {
    public static void main(String[] args) {

        SpringApplication springApplication = new SpringApplication(StarterApp.class); // Define the source, where to start the application
        springApplication.run(); // this helps me to start my spring boot project
    }
}
