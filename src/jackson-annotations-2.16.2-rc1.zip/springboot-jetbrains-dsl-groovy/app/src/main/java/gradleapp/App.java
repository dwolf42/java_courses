//package gradleapp;
//
//import gradleapp.spring_beans_atconfiguration_atbean.Customer;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Bean;
//
//@SpringBootApplication
//public class App {
//    public String getGreeting() {
//        return "Hello World!";
//    }
//
//    public static void main(String[] args) {
////        System.out.println(new App().getGreeting());
//        SpringApplication.run(App.class, args);
//    }
//
//    // This is a method of return-type Customer (like String), named customer
//    // It gets the parameter String address injected through the @Autowired annotation
//    @Bean
//    public Customer customer(@Autowired String address) {
//        return new Customer("Clara Foster", address);
//    }
//
//    // Qualifier:
//    // The @Qualifier annotation provides a way to say, which method of Addresses should be used.
//    @Bean
//    public Customer customerWithQualifier(@Qualifier("address2") String address) {
//        return new Customer("Pantana Smorg", address);
//    }
//
//    // I assume, as Spring handles everything before the execution of a method and everything after,
//    // it needs to get a return value, so it can process further.
//    @Bean
//    public Customer temporary(@Autowired Customer customer) {
//        System.out.println(customer);
//        return customer;
//    }
//
//    @Bean
//    public Customer temporaryWithQualifier(@Qualifier("customerWithQualifier") Customer customer) {
//        System.out.println(customer);
//        return customer;
//    }
//}
