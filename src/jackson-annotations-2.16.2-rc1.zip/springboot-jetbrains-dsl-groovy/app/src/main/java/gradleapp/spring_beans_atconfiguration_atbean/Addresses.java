package gradleapp.spring_beans_atconfiguration_atbean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Addresses {

    @Bean
    public String address() {
        return "Green Street, 102";
    }

    // Qualifier example:
    // The method can be chosen by using the @Qualifier annotation in App.java
    @Bean
    public String address2() {
        return "Wolf Alley, 2";
    }
}
