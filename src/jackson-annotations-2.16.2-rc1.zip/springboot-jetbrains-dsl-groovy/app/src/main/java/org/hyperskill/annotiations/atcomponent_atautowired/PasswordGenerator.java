package org.hyperskill.annotiations.atcomponent_atautowired;//package com.hyperskill.app.atcomponent_atautowired;
//
//import org.springframework.stereotype.Component;
//import java.util.Random;
//
//@Component
//public class PasswordGenerator {
//    private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyz";
//    private static final Random random = new Random();
//
//    public String generate(int length) {
//        StringBuilder result = new StringBuilder();
//
//        for (int i = 0; i < length; i++) {
//            int index = random.nextInt(CHARACTERS.length());
//            result.append(CHARACTERS.charAt(index));
//        }
//
//        return result.toString();
//    }
//}