package org.hyperskill.interfaces;

public interface Epsilon extends Alpha, Betha, Ceta, Car{

}
