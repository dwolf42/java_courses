package org.hyperskill.runners;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

// For this to work it must be placed in the Spring app directory
@Component
class Runner implements CommandLineRunner {
    @Override
    public void run(String... args) {
        System.out.println("Hello, Spring!");
        System.out.println("I just have a 2nd main method - lol!");
    }
}
