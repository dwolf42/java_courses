package org.hyperskill.annotiations.atcomponent_atautowired;//package com.hyperskill.app.atcomponent_atautowired;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.stereotype.Component;
//
//@Component
//public class Building {
//    private final PasswordGenerator generator;
//
//    @Autowired
//    public Building(PasswordGenerator generator) {
//        this.generator = generator;
//    }
//
//@Bean
//    public Building dispaly(@Autowired Building build) {
//        System.out.println("A short password: " + generator.generate(5));
//        System.out.println("A long password: " + generator.generate(10));
//        return build;
//    }
//}
