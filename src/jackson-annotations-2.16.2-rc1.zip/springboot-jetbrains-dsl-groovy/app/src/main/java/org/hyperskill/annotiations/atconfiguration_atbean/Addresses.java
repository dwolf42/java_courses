package org.hyperskill.annotiations.atconfiguration_atbean;//package com.hyperskill.app.atconfiguration_atbean;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class Addresses {
//
//    @Bean
//    public String address() {
//        return "Green Street, 102";
//    }
//}
