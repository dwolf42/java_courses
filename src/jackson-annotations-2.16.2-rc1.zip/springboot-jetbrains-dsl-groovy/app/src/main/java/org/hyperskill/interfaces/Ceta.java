package org.hyperskill.interfaces;

public interface Ceta {
}
