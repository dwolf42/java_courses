package org.hyperskill.interfaces;

interface Betha {

}
