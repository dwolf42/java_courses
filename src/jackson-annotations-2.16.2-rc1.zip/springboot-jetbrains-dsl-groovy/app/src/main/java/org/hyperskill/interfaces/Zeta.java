package org.hyperskill.interfaces;

public class Zeta extends Delta implements Alpha, Betha, Ceta, Car {

}
