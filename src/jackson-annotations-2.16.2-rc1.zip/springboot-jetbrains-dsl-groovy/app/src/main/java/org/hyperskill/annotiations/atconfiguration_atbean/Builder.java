package org.hyperskill.annotiations.atconfiguration_atbean;//package com.hyperskill.app.atconfiguration_atbean;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class Builder {
///*
//* Die Bean address() wird in die Bean customer als parameter injected, damit ich
//* in der Bean customer ein neues Object Customer erstellen kann, dem ich einen Namen gebe und
//* die injizierte address.
//* Dann gehe ich hin und injiziere das eben erstellte Object Customer in das Bean temporary,
//* wo es ausgedruckt und zurückgegeben wird.
//* Configuration sagt im Grunde nichts anderes aus, als dass ich Spring anweise, diese Class
//* zu verwalten und mit Bean sage ich, welche Teile davon verwaltet werden müssen.
//* Die Class Customer muss nicht verbunden werden, weil ich sie durch das Bean customer mit
//* allem füttere, was sie braucht.
//* */
//    @Bean
//    public Customer customer(@Autowired String address) {
//        return new Customer("Clara Foster", address);
//    }
//
//    @Bean
//    public Customer temporary(@Autowired Customer customer) {
//        System.out.println(customer);
//        return customer;
//    }
//}
