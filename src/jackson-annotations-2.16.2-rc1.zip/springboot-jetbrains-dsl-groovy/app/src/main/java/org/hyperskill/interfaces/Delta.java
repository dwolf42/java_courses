package org.hyperskill.interfaces;

public class Delta implements Alpha, Betha, Ceta {
}
