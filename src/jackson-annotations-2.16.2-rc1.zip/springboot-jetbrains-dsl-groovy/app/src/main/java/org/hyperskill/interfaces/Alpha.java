package org.hyperskill.interfaces;

public interface Alpha {
}
