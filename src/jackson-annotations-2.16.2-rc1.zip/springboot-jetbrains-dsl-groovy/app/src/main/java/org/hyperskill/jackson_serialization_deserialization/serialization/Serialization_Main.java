package org.hyperskill.jackson_serialization_deserialization.serialization;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.Date;

class Serialization_Main {
    public static void main(String[] args) throws JsonProcessingException {
        Serialization_Post post = new Serialization_Post(
                1,
                new Date(),
                "I learned how to use Jackson!",
                10,
                Arrays.asList("Well done!", "Great job!")
        );


        // Create an ObjectMapper which provides us with an easy way to convert Java objects to JSON and vice versa
        ObjectMapper objectMapper = new ObjectMapper();

        // The writeValueAsString method generates a JSON and returns it as a string.
        String postAsString = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(post);
        // is the one-line-print -> objectMapper.writeValueAsString(post);

        System.out.println(postAsString);
    }
}
